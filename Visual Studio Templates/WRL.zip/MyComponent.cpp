#include "pch.h"
#include "MyComponent.h"

namespace $safeprojectname$
{
    IFACEMETHODIMP MyComponent::Foo (HSTRING someString, IMyCallbackProvider* myCallback)
    {
        myCallback->Call(someString);
 
        return S_OK;
    }
}
