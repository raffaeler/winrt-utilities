﻿#pragma once

// instead of declaring PROXY_CLSID_IS in PreprocessorDefinitions (C/C++ project options)
// we declare PROXY_CLSID this way. If you prefer PROXY_CLSID_IS, you can change by"
// - add PROXY_CLSID_IS={{...}} (generate proxy with option 3 in tool GuidGen) in preprocessor definitions
// - delete the following declaration
#define PROXY_CLSID $guid4$



#include <SDKDDKVer.h>
 
#define WIN32_LEAN_AND_MEAN
 
//Windows Header Files:
#include <windows.h>
#include <assert.h>
#include <tchar.h>
#include <Strsafe.h>
 
//WRL
#include <wrl\client.h>
#include <wrl\implements.h>
#include <wrl\ftm.h>
#include <wrl\event.h>
#include <wrl\wrappers\corewrappers.h>
#include <wrl\module.h>
